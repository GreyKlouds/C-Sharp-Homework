﻿namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // holds array size to 5 elements.
            const int ArrayLength = 5;

            // base array for user input
            int[] Array = new int[ArrayLength];


            Console.WriteLine("Enter 5 numbers between 10 and 100:");

            // read in 5 numbers from user within range of 10 - 100.
            for (int i = 0; i < ArrayLength; i++)
            {
                int userInput = Convert.ToInt32(Console.ReadLine());
                if (userInput >= 10 && userInput <= 100)
                {
                    Array[i] = userInput;
                }
                else
                {
                    Console.WriteLine("Error!! Input out of range! Please run program again!");
                    return;
                }
            }
            Console.WriteLine("\n");

            //smallest posible array:

            int[] smallestArray = Array.Distinct().ToArray();
            Console.Write("The smallest possible array size in this case is: " + smallestArray.Length + "\n");

            for (int j = 0; j < smallestArray.Length; j++)
            {
                // displays the numbers in the array that are NOT duplicated.
                Console.WriteLine(smallestArray[j]);
            }

            Console.WriteLine("\n");

            Console.WriteLine("The complete list of numbers input by the user:");

            // output numbers contained in the base Array.
            for (int j = 0; j < ArrayLength; j++)
            {
                Console.WriteLine(Array[j]);
            }
        }
    }
}
