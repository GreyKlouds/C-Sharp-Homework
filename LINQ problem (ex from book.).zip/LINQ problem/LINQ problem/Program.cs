﻿using System;
using System.Linq;

class LINQWithSimpleTypeArray
{
    static void Main()
    {
        // create an int array
        var values = new[] { 1, 2, 3,4,5,6,7,8,9,10};

        // display original value
        Console.Write("Original array:\n");
        foreach(var elem in values)
        {
            Console.Write(elem + "\n");
        }

        // LINQ query that obtains values greater than 4 from the array
        var filtered =
            from value in values // data source is values
            where value > 4
            select value;

        //display filtered results
        Console.WriteLine("\nArray values grater than 4:");
        foreach(var elem2 in filtered)
        {
            Console.WriteLine(elem2);
        }

        //use orderby clause to sort origninal values in ascending order
        var sorted = from value in values // data sorce is values
                     orderby value
                     select value;

        Console.Write("\nOriginal array, sorted:\n");
        foreach(var elem3 in sorted)
        {
            Console.WriteLine(elem3);
        }

        // filter original array and sort results in decending order
        var sortAndFilter = from value in values //data source is values
                            where value > 4
                            orderby value descending
                            select value;

        // display the filtered and sorted results
        Console.Write("\nValues greater than 4, desending order (one query):\n");

        foreach(var elme4 in sortAndFilter)
        {
            Console.WriteLine(elme4);
        }

        Console.WriteLine();
    }
}