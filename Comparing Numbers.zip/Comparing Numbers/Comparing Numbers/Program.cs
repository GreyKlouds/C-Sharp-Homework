﻿using System; 

namespace Numbers
{
    class Numbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: ");
            int firstNumber = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a second number: ");
            int secondNumber = int.Parse(Console.ReadLine());

            if(firstNumber > secondNumber)
            {
                Console.WriteLine(firstNumber + " is larger.");
            }
            
            if(secondNumber > firstNumber)
            {
                Console.WriteLine(secondNumber + " is largest.");
            }

            if (firstNumber == secondNumber)
            {
                Console.WriteLine("Both numbers are equal.");
            }
        }
    }
}