﻿using System;


namespace RectangleTest
{
    public class Rectangle
    {
        public decimal Length
        {
            set;
            get;
        }
        public decimal Width
        {
            set;
            get;
        }

        public readonly float area;
        public readonly float perimeter;



        public void SetLengthAndWidth(decimal length, decimal width)
        {
            Length = length;
            Width = width;

            if ((length < 0 || length > 20) || (width < 0 || width > 20))
            {
                throw new ArgumentOutOfRangeException(nameof(length));
            }
          
        }
        public decimal getArea()
        {
            decimal Area = Length * Width;
            return Area;
        }

        public decimal getPerimeter()
        {
            decimal Perimeter = 2 * (Length * Width);
            return Perimeter;
        }
    }
}
