﻿using System;

namespace RectangleTest;
class RectangleTest
{
    static void Main()
    {
        var calculations = new Rectangle();
        
        // length and width defaults set
        calculations.SetLengthAndWidth(1,1);
        // defualt values from statment above.
        Console.WriteLine(calculations.getArea());
        Console.WriteLine();
        Console.WriteLine(calculations.getPerimeter());
        Console.WriteLine("Enter a length between 0.0 and 20.0:\n");
        decimal length = Convert.ToDecimal(Console.ReadLine());
        Console.WriteLine("Enter a width between 0.0 and 20.0:\n");
        decimal width = Convert.ToDecimal(Console.ReadLine());


        calculations.SetLengthAndWidth(length, width);
        // calculations after new values passed in.
        Console.WriteLine("The area of the rectangle is");
        Console.WriteLine(calculations.getArea());
        Console.WriteLine();
        Console.WriteLine("The perimeter of the rectangle is:");
        Console.WriteLine(calculations.getPerimeter());
    }
}